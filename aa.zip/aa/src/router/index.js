import Vue from 'vue'
import Router from 'vue-router'
import aa from '@/views/aa'
import bb from '@/views/bb'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      redirect:"/aa"
      // 重定向
    },
    {
      path: '/aa',
      name: 'aa',
      component: aa
    },,
    {
      path: '/bb',
      name: 'bb',
      component: bb
    },
  ]
})
